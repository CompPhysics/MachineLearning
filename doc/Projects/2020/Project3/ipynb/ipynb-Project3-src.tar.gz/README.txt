This IPython notebook Project3.ipynb does not require any additional
programs.
