This IPython notebook DimRed.ipynb does not require any additional
programs.
