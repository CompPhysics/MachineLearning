This IPython notebook week35.ipynb does not require any additional
programs.
