This IPython notebook How2ReadData.ipynb does not require any additional
programs.
