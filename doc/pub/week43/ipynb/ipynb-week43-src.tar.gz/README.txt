This IPython notebook week43.ipynb does not require any additional
programs.
