This IPython notebook Recurrent.ipynb does not require any additional
programs.
