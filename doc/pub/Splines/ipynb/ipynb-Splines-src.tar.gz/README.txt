This IPython notebook Splines.ipynb does not require any additional
programs.
