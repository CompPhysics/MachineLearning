This IPython notebook week39.ipynb does not require any additional
programs.
