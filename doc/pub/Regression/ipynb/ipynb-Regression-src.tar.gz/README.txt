This IPython notebook Regression.ipynb does not require any additional
programs.
