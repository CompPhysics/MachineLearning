This IPython notebook week40.ipynb does not require any additional
programs.
