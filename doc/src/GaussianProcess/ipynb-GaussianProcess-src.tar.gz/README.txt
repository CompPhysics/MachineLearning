This IPython notebook GaussianProcess.ipynb does not require any additional
programs.
