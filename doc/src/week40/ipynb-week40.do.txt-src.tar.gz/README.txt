This IPython notebook week40.do.txt.ipynb does not require any additional
programs.
